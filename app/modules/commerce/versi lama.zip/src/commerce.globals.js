// Holds onto order objects, keyed by order_id.
var _commerce_order = {};

// Holds onto the current product display.
var _commerce_product_display = null;

// Holds onto the current product display's referenced product entity field names.
var _commerce_product_attribute_field_names = null;

// Holds onto the current product display's referenced product id.
var _commerce_product_display_product_id = null;
